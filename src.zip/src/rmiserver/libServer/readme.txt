========================
Run server DESCRIPTION
========================
First of all have to edit config file DBNodes.conf - the contents are hostaname+DBname ; username with grants for this DB ; password
Have to edit server.policy - add FilePermition for server directory. Run applicqtion using start script. 
Don't forget to run rmiregistry first.

