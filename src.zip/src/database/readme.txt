========================
Database DESCRIPTION
========================
First of all have to create user with appropriate DB-permitions (connect,select,insert,delete etc.)
After you havwe to create the node database structure and insert data in tables books,db_options and 
optional users (you can do that using Registration).

